/// @file
/// @ingroup common_utils
#pragma once

#include <cgraph/list.h>
#include <common/geom.h>

DEFINE_LIST(boxes, boxf)
